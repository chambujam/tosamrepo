# if elif and else

running

route = input("Enter the route: ")

if route.casefold() == "sarjapur":
    print("pls take green line metro")
elif route.casefold() == "marathalli":
    print('pls take Yellow line metro')
elif route.casefold() == "airport":
    print('pls take Red line metro')
else:
    print("please enter one of these as routes 'sarjapur' or 'marathalli' or 'airport'")
   
# gmail, GMAIL, GMail, Gmail, gMAIL --> gmail.com






